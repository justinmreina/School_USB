#ifndef _GLOBALS_H
#define _GLOBALS_H

//Windows
#include <iostream>

//Project
#include "Class.h"


#endif /* _GLOBALS_H */

